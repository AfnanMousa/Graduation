class ProductsController < ApplicationController

    def productPage
    end

    # def signUp
    # end

    # def resetPassword
    # end

    # def index
    # end

end
