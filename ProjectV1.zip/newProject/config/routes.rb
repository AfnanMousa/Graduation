Rails.application.routes.draw do
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Defines the root path route ("/")
  # root "articles#index"


  get'registeration/login'
  get'registeration/resetPassword'
  get'registeration/signup'
  # get'home_page/index'
  get'products/productPage'
  get'products/addProduct'
  get'products/changeQuantity'
  get'products/productPageAfterUpdate'

  # match ':controller(\:action(\:id))',:via =>:get # go to any controllers

end
